10 inch mini itx case by Moschmosch on Thingiverse: https://www.thingiverse.com/thing:4579587

Summary:
I needed a 10 inch case for a mini ITX mainboard for a low power cluster project.There is still some optimization needed. But it works as expected. Its size is optimized so it fits into a prusa mk3s.I had some trouble with warping but i was able to solve it by some minor changes to the object and by increasing the bed temperature(70°).It also has a hole for the power LED and a button (16mm)